import { useState } from "react";

function StudentCard({ name, department, year, startingLikes }) {
  const [likes, setLikes] = useState(startingLikes);

  return (
    <article className="student-card">
      <div className="avatar">{name.charAt(0)}</div>
      <div className="student-details">
        <p className="eyebrow">STUDENT PROFILE</p>
        <h2>{name}</h2>
        <p className="detail">{department}</p>
        <p className="detail">{year}</p>
        <button className="like-button" onClick={() => setLikes((value) => value + 1)}>
          ♥ Like <span>{likes}</span>
        </button>
      </div>
    </article>
  );
}

function Counter() {
  const [count, setCount] = useState(0);

  return (
    <section className="counter-panel">
      <div>
        <p className="eyebrow">USESTATE HOOK</p>
        <h2>Interactive Counter</h2>
        <p className="muted">The number changes when you click a button.</p>
      </div>
      <div className="counter-controls">
        <button aria-label="Decrease" onClick={() => setCount((value) => value - 1)}>−</button>
        <output>{count}</output>
        <button aria-label="Increase" onClick={() => setCount((value) => value + 1)}>+</button>
        <button className="reset" onClick={() => setCount(0)}>Reset</button>
      </div>
    </section>
  );
}

export default function App() {
  const students = [
    { id: 1, name: "Aarav Sharma", department: "Computer Engineering", year: "Third Year", startingLikes: 3 },
    { id: 2, name: "Mira Patel", department: "Information Technology", year: "Second Year", startingLikes: 5 },
    { id: 3, name: "Rohan Deshmukh", department: "Computer Engineering", year: "Final Year", startingLikes: 2 }
  ];

  return (
    <main className="page">
      <header className="hero">
        <div className="react-mark">⚛</div>
        <p className="eyebrow">REACT FUNDAMENTALS</p>
        <h1>Props <span>&</span> State</h1>
        <p className="intro">A simple React app demonstrating JSX, functional components, props, and the useState hook.</p>
        <div className="tags"><span>JSX</span><span>Functional Components</span><span>Props</span><span>useState</span></div>
      </header>

      <section className="section">
        <div className="section-heading">
          <div><p className="eyebrow">01 / PASSING DATA</p><h2>Student Profiles</h2></div>
          <span className="badge">{students.length} profiles</span>
        </div>
        <p className="muted">Each card receives student details through props and maintains its own Like count with useState.</p>
        <div className="student-grid">
          {students.map((student) => (
            <StudentCard
              key={student.id}
              name={student.name}
              department={student.department}
              year={student.year}
              startingLikes={student.startingLikes}
            />
          ))}
        </div>
      </section>

      <Counter />

      <section className="concepts">
        <h2>Concepts demonstrated</h2>
        <div className="concept-grid">
          <div><b>01</b><h3>JSX</h3><p>Write HTML-like UI syntax inside JavaScript.</p></div>
          <div><b>02</b><h3>Props</h3><p>Pass data from App to reusable StudentCard components.</p></div>
          <div><b>03</b><h3>useState</h3><p>Track and update likes and the counter interactively.</p></div>
        </div>
      </section>
      <footer>Built with React · JSX · Vite</footer>
    </main>
  );
}