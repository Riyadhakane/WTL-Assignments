# React Props and useState Assignment

A React application using JSX and functional components. It demonstrates passing data using props and managing state using the `useState` hook.

## Features
- Reusable `StudentCard` functional component
- Passes student name, department, year, and initial likes through props
- Each student card has an independent Like counter using `useState`
- Interactive counter with increase, decrease, and reset buttons
- Responsive layout for mobile and desktop

## Requirements
Install Node.js (which includes npm).

## Run locally
1. Extract the ZIP.
2. Open Terminal in this project folder.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local URL printed by Vite, usually `http://localhost:5173`.

## Production build
Run `npm run build`.

## Structure
- `index.html` — HTML entry point
- `src/main.jsx` — React entry point
- `src/App.jsx` — components, props, and state
- `src/styles.css` — styling
- `package.json` — dependencies and scripts
