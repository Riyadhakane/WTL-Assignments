// const http = require("http");

// const server = http.createServer((req, res) => {
//     res.end("Hello server");
// });

// server.listen(3000, () => {
//     console.log("Server running on port 3000");
// });

// const http = require("http");

// const server = http.createServer((req, res) => {
//     console.log(req.method); // for url req.url
//     console.log(req.url);
//     res.end("Hello");
// });

// server.listen(3000, () =>{console.log("Server running on port 3000")});

// const http = require("http");

// const server = http.createServer((req, res) => {

//     if (req.url === "/" && req.method === "GET") {
//         res.end("Home Page");
//     }
//     else if (req.url === "/about" && req.method === "GET") {
//         res.end("About Page");
//     }
//     else {
//         res.statusCode = 404;
//         res.end("Page Not Found");
//     }
// });

// server.listen(3000, () => {
//     console.log("Server running on port 3000");
// });

// const http = require("http");

// const server = http.createServer((req, res) => {
//     res.setHeader("Content-Type", "application/json");

//     if (req.url === "/") {
//         res.end(JSON.stringify({ message: "Home Page" }));
//     } 
//     else if (req.url === "/about") {
//         res.end(JSON.stringify({ message: "About Page" }));
//     } 
//     else {
//         res.statusCode = 404;
//         res.end(JSON.stringify({ error: "Not Found" }));
//     }
// });

// server.listen(3000);

const http = require("http");

const users = require("./data");

const server = http.createServer((req, res) => {

    res.setHeader("Content-Type", "application/json");

    // =========================
    // GET ALL USERS
    // =========================

    if (req.method === "GET" && req.url === "/users") {

        res.statusCode = 200;

        res.end(JSON.stringify(users));
    }


    // =========================
    // GET USERS USING QUERY
    // =========================

    else if (req.method === "GET" && req.url.startsWith("/search")) {

        const url = new URL(req.url, `http://${req.headers.host}`);

        const name = url.searchParams.get("name");
        const city = url.searchParams.get("city");

        let result = users;

        if (name) {
            result = result.filter(user =>
                user.name.toLowerCase() === name.toLowerCase()
            );
        }

        if (city) {
            result = result.filter(user =>
                user.city.toLowerCase() === city.toLowerCase()
            );
        }

        res.statusCode = 200;

        res.end(JSON.stringify(result));
    }


    else if (req.method === "GET" && req.url.startsWith("/users/")) {

        const id = Number(req.url.split("/")[2]);

        const user = users.find(user => user.id === id);

        if (user) {
            res.statusCode = 200;
            res.end(JSON.stringify(user));
        } 
        else {
            res.statusCode = 404;
            res.end(JSON.stringify({
                message: "User not found"
            }));
        }
    }

    else if (req.method === "POST" && req.url === "/users") {

        let body = "";

        req.on("data", chunk => {
            body += chunk;
        });

        req.on("end", () => {

            const newUser = JSON.parse(body);

            newUser.id = users.length + 1;

            users.push(newUser);

            res.statusCode = 201;

            res.end(JSON.stringify({
                message: "User added successfully",
                user: newUser
            }));
        });
    }

    else if (req.method === "PUT" && req.url.startsWith("/users/")) {

        const id = Number(req.url.split("/")[2]);

        let body = "";

        req.on("data", chunk => {
            body += chunk;
        });

        req.on("end", () => {

            const updatedData = JSON.parse(body);

            const index = users.findIndex(user => user.id === id);

            if (index === -1) {
                res.statusCode = 404;

                res.end(JSON.stringify({
                    message: "User not found"
                }));

                return;
            }

            users[index] = {
                id: id,
                ...updatedData
            };

            res.statusCode = 200;

            res.end(JSON.stringify({
                message: "User updated successfully",
                user: users[index]
            }));
        });
    }


    // =========================
    // DELETE USER
    // =========================

    else if (req.method === "DELETE" && req.url.startsWith("/users/")) {

        const id = Number(req.url.split("/")[2]);

        const index = users.findIndex(user => user.id === id);

        if (index === -1) {
            res.statusCode = 404;

            res.end(JSON.stringify({
                message: "User not found"
            }));

            return;
        }

        const deletedUser = users.splice(index, 1);

        res.statusCode = 200;

        res.end(JSON.stringify({
            message: "User deleted successfully",
            user: deletedUser[0]
        }));
    }


    // =========================
    // INVALID REQUEST
    // =========================

    else {

        res.statusCode = 404;

        res.end(JSON.stringify({
            message: "Route not found"
        }));
    }

});

server.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});