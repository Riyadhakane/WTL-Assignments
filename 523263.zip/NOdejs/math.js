// function add(a, b) {
//     return a + b;
// }

// module.exports = {add};

const fs = require("fs");

const data = fs.readFileSync("data.txt", "utf-8");
console.log(data);
console.log("Finished");


fs.readFile("data.txt", "utf-8", (err, data) => {
    if(err){
        console.log(err);
        return;
    }
    console.log(data);
});
console.log("Finished 2");


fs.writeFile("data.txt", "Hello Node.js", (err) => {
    if (err) {
        console.log(err);
        return;
    }
    console.log("Done");
});
console.log("Finished 3");

fs.appendFile("data.txt", "Appended text", (err) => {
    if(err){
        console.log(err);
        return;
    }
    console.log("Appended");
})

console.log("Finished 4");

// fs.unlink("data2.txt", (err)=>{
//     if(err){
//     console.log(err);
//     return;
//     }
//     console.log("Deleted data2.txt");
// })

// fs.mkdir("myFolder", (err) => {
//     if (err) {
//         console.log(err);
//         return;
//     }
//     console.log("Directory");
// });


async function readData() {
    try {
        const data = await fs.readFile("data.txt", "utf-8");
        console.log(data);
    } catch (err) {
        console.log(err);
    }
}

readData();
console.log("Finished async");
