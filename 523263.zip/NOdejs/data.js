const users = [
    {
        id: 1,
        name: "Shravani",
        age: 20,
        city: "Nashik"
    },
    {
        id: 2,
        name: "Rahul",
        age: 21,
        city: "Pune"
    },
    {
        id: 3,
        name: "Priya",
        age: 22,
        city: "Mumbai"
    }
];

module.exports = users;