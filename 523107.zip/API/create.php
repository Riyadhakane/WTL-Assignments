<?php

header("Content-Type: application/json");

require_once "db.php";

$rawBody = file_get_contents("php://input");

$data = json_decode($rawBody, true);

$name = $data["name"];
$email = $data["email"];

$sql = "INSERT INTO students (name, email) VALUES ('$name', '$email')";

if ($conn->query($sql)) {
    echo json_encode([
        "message" => "Student created successfully",
        "id" => $conn->insert_id
    ]);
} else {
    echo json_encode([
        "message" => "Error creating student"
    ]);
}

?>