<?php

header("Content-Type: application/json");

require_once "db.php";

$rawBody = file_get_contents("php://input");

$data = json_decode($rawBody, true);

$id = $data["id"];

$sql = "DELETE FROM students WHERE id=$id";

if ($conn->query($sql)) {
    echo json_encode([
        "message" => "Student deleted successfully"
    ]);
} else {
    echo json_encode([
        "message" => "Error deleting student"
    ]);
}

?>