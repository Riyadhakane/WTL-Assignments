<?php

header("Content-Type: application/json");

require_once "db.php";

$rawBody = file_get_contents("php://input");

$data = json_decode($rawBody, true);

$id = $data["id"];
$name = $data["name"];
$email = $data["email"];

$sql = "UPDATE students
        SET name='$name', email='$email'
        WHERE id=$id";

if ($conn->query($sql)) {

    echo json_encode([
        "message" => "Student updated successfully"
    ]);

} else {

    echo json_encode([
        "message" => "Error updating student"
    ]);
}

?>