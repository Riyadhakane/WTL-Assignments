
const mongoose = require("mongoose");
const Student = require("../models/Student");

require("dotenv").config();

let cachedConnection = null;

async function connectDB() {
    if (cachedConnection && mongoose.connection.readyState === 1) {
        return;
    }

    if (!process.env.MONGODB_URI) {
        throw new Error("MONGODB_URI is not configured");
    }

    cachedConnection = await mongoose.connect(
        process.env.MONGODB_URI
    );
}

module.exports = async function handler(req, res) {
    // Allow read-only GET requests
    if (req.method !== "GET") {
        return res.status(405).json({
            message: "Method not allowed. Use GET."
        });
    }

    try {
        await connectDB();

        const totalStudents = await Student.countDocuments();

        const topStudents = await Student.find()
            .sort({ marks: -1, rollNo: 1 })
            .limit(5)
            .select("name rollNo department marks -_id")
            .lean();

        return res.status(200).json({
            totalStudents,
            topStudents
        });
    } catch (error) {
        console.error("Summary API error:", error.message);

        return res.status(500).json({
            message: "Could not retrieve student summary"
        });
    }
};
