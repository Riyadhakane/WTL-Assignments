
const studentForm = document.getElementById("studentForm");
const studentTable = document.getElementById("studentTable");
const message = document.getElementById("message");

// Load and display all students
async function loadStudents() {
    studentTable.innerHTML =
        '<tr><td colspan="6">Loading students...</td></tr>';

    try {
        const response = await fetch("/api/students");
        const students = await response.json();

        if (!response.ok) {
            throw new Error(students.message || "Could not load students");
        }

        studentTable.innerHTML = "";

        if (students.length === 0) {
            studentTable.innerHTML =
                '<tr><td colspan="6">No students found. Add your first student above.</td></tr>';
            return;
        }

        students.forEach(function (student) {
            const row = document.createElement("tr");

            const values = [
                student.name,
                student.rollNo,
                student.email,
                student.department,
                student.marks
            ];

            values.forEach(function (value) {
                const cell = document.createElement("td");
                cell.textContent = value;
                row.appendChild(cell);
            });

            // Edit and Delete buttons
            const actions = document.createElement("td");

            const editButton = document.createElement("button");
            editButton.textContent = "Edit";

            editButton.addEventListener("click", function () {
                document.getElementById("studentId").value = student._id;
                document.getElementById("name").value = student.name;
                document.getElementById("rollNo").value = student.rollNo;
                document.getElementById("email").value = student.email;
                document.getElementById("department").value = student.department;
                document.getElementById("marks").value = student.marks;

                document.getElementById("formTitle").textContent = "Update Student";
                document.getElementById("submitBtn").textContent = "Save Changes";
                document.getElementById("cancelBtn").hidden = false;

                studentForm.scrollIntoView({ behavior: "smooth" });
            });

            const deleteButton = document.createElement("button");
            deleteButton.textContent = "Delete";
            deleteButton.className = "delete-btn";

            deleteButton.addEventListener("click", async function () {
                if (!confirm("Are you sure you want to delete this student?")) {
                    return;
                }

                try {
                    const result = await fetch(
                        "/api/students/" + student._id,
                        { method: "DELETE" }
                    );

                    const data = await result.json();
                    message.textContent = data.message;

                    if (result.ok) {
                        await loadStudents();
                    }
                } catch (error) {
                    message.textContent = "Could not connect to the server.";
                }
            });

            actions.appendChild(editButton);
            actions.appendChild(deleteButton);
            row.appendChild(actions);
            studentTable.appendChild(row);
        });

    } catch (error) {
        studentTable.innerHTML =
            '<tr><td colspan="6">Could not load records. Check the server and database connection.</td></tr>';

        message.textContent = error.message;
    }
}

// Add a new student or update an existing student
studentForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    const id = document.getElementById("studentId").value;

    const student = {
        name: document.getElementById("name").value.trim(),
        rollNo: Number(document.getElementById("rollNo").value),
        email: document.getElementById("email").value.trim(),
        department: document.getElementById("department").value.trim(),
        marks: Number(document.getElementById("marks").value)
    };

    try {
        const response = await fetch(
            id ? "/api/students/" + id : "/api/students",
            {
                method: id ? "PUT" : "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(student)
            }
        );

        const data = await response.json();
        message.textContent = data.message;

        if (response.ok) {
            studentForm.reset();

            document.getElementById("studentId").value = "";
            document.getElementById("formTitle").textContent = "Add New Student";
            document.getElementById("submitBtn").textContent = "Add Student";
            document.getElementById("cancelBtn").hidden = true;

            await loadStudents();
        }
    } catch (error) {
        message.textContent = "Could not connect to the server.";
    }
});

// Cancel editing
document.getElementById("cancelBtn").addEventListener("click", function () {
    studentForm.reset();

    document.getElementById("studentId").value = "";
    document.getElementById("formTitle").textContent = "Add New Student";
    document.getElementById("submitBtn").textContent = "Add Student";
    this.hidden = true;
});

// Refresh student records
document.getElementById("refreshBtn").addEventListener("click", loadStudents);

// Display students when the page opens
loadStudents();
