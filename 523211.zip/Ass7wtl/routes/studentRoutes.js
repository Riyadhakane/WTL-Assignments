
const express = require("express");
const Student = require("../models/Student");

const router = express.Router();

// CREATE: Add a new student
router.post("/", async (req, res) => {
    try {
        const student = await Student.create(req.body);

        res.status(201).json({
            message: "Student added successfully",
            student
        });
    } catch (error) {
        res.status(400).json({
            message: "Could not add student. Check required fields and duplicate roll number/email."
        });
    }
});

// READ: Get all students
router.get("/", async (req, res) => {
    try {
        const students = await Student.find().sort({ rollNo: 1 });
        res.json(students);
    } catch (error) {
        res.status(500).json({
            message: "Could not fetch students"
        });
    }
});

// UPDATE: Update a student using their MongoDB ID
router.put("/:id", async (req, res) => {
    try {
        const student = await Student.findByIdAndUpdate(
            req.params.id,
            req.body,
            {
                new: true,
                runValidators: true
            }
        );

        if (!student) {
            return res.status(404).json({
                message: "Student not found"
            });
        }

        res.json({
            message: "Student updated successfully",
            student
        });
    } catch (error) {
        res.status(400).json({
            message: "Could not update student"
        });
    }
});

// DELETE: Delete a student using their MongoDB ID
router.delete("/:id", async (req, res) => {
    try {
        const student = await Student.findByIdAndDelete(req.params.id);

        if (!student) {
            return res.status(404).json({
                message: "Student not found"
            });
        }

        res.json({
            message: "Student deleted successfully"
        });
    } catch (error) {
        res.status(400).json({
            message: "Could not delete student"
        });
    }
});

module.exports = router;
