
const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
require("dotenv").config();

const app = express();

app.use(express.json());

// Serve HTML, CSS and JavaScript
app.use(express.static(path.join(__dirname, "public")));

// Home page
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Student CRUD routes
const studentRoutes = require("./routes/studentRoutes");
app.use("/api/students", studentRoutes);

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI)
    .then(() => {
        console.log("MongoDB connected successfully!");

        // Read-only student summary endpoint for local testing
        app.get("/api/summary", async (req, res) => {
            try {
                const Student = require("./models/Student");

                const totalStudents = await Student.countDocuments();

                const topStudents = await Student.find()
                    .sort({ marks: -1, rollNo: 1 })
                    .limit(5)
                    .select("name rollNo department marks -_id")
                    .lean();

                res.json({
                    totalStudents,
                    topStudents
                });
            } catch (error) {
                console.error("Summary error:", error.message);
                res.status(500).json({
                    message: "Could not retrieve student summary"
                });
            }
        });

        app.listen(process.env.PORT || 3000, () => {
            console.log("Server running on http://localhost:3000");
        });
    })
    .catch((error) => {
        console.error("MongoDB connection failed:", error.message);
    });


    